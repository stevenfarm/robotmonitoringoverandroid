package com.example.admin.robotermonitor;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by Admin on 08.01.2018.
 */

public class Mainactivity extends AppCompatActivity implements View.OnClickListener {


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);


        Button activity2Button  = (Button) this.findViewById(R.id.button1);
        activity2Button.setOnClickListener(this);

    }

    public void onClick(View v) {

        //  Activity 2 starten
        Intent intent = new Intent(this, accelerometer.class);
        this.startActivity(intent);
    }
}
