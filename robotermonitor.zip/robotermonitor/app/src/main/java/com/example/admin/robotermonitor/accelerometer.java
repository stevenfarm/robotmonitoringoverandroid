package com.example.admin.robotermonitor;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

//Hauptklasse
public class accelerometer extends AppCompatActivity implements View.OnClickListener {
    String JSON_STRING;
    private class BackgroundTask extends AsyncTask<Void, Void, String> {
        String JSON_URL;
        //Ausführen der URL
        @Override
        protected void onPreExecute() {

            //Hier URL zwischen "https:.....php" eingeben
           JSON_URL ="http:... .php"; }
        @Override
        protected String doInBackground(Void... params) {
            try {
                StringBuilder JSON_DATA = new StringBuilder();
                URL url = new URL(JSON_URL);
                HttpURLConnection httpURLConnection =
                        (HttpURLConnection) url.openConnection();
                InputStream in =
                        httpURLConnection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                while ((JSON_STRING = reader.readLine())!=null) {
                    JSON_DATA.append(JSON_STRING).append("\n");
                }
                return JSON_DATA.toString().trim();
            }
            catch (Exception e) {
                e.printStackTrace(); }
            return null; }
        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
        @Override
        protected void onPostExecute(String result) {
            TextView json = (TextView) findViewById(R.id.textview);
            json.setText(result);
        }
    }
    //Browser Button
    private Button externeActivityButton;
    //Hauptseite Button
    private Button MainactivityButton;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.accelerometer);

        MainactivityButton = (Button) this.findViewById(R.id.button1);
        MainactivityButton.setOnClickListener(this);

        externeActivityButton = (Button) this.findViewById(R.id.button2);
        externeActivityButton.setOnClickListener(this);
    }
    //Was passieren soll wenn Browser Button geklickt wurde
    @Override
    public void onClick(View v) {
        if(v == externeActivityButton) {
            Intent intent = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER);
            PackageManager pm = getPackageManager();
            ComponentName cn  = intent.resolveActivity(pm);

            if(cn != null) {
                startActivity(intent);
            }
            else {
                Toast t = Toast.makeText(this, "Kein Browser vorhanden!", Toast.LENGTH_SHORT);
                t.show();
            }
        }
        else if(v == MainactivityButton) {
            Intent intent = new Intent(this, Mainactivity.class);
            startActivity(intent);
        }
    }

}
